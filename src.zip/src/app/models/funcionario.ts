export class Funcionario {}
